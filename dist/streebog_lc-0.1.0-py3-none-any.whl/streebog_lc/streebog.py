def streebog_256(data) -> str:
    return ""


def streebog_512(data) -> str:
    return ""
