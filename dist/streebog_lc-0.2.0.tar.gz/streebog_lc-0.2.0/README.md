Python library for computing streebog hashes with go under the hood

currently in development